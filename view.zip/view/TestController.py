import ui
import threading




class Controller:
	def __init__(self):
		self.__view = ui.Ui()
		self.__view.connect_signals(self)
	
	def throw_app(self):
		self.__view.throw_ui()
		
	def on_close(self,widget,data=None):
		self.__view.stop_ui()
	
	def on_cursor(self, widget,data=None): #Accede al Cursor
		self.__view.change_operation(2)
	
	def on_node(self,widget,data=None): #Accede a Crear el Nodo
		self.__view.change_operation(1)
	
	def on_add_edge(self, widget, data=None): #Accede a Crear el Arco
		self.__view.change_operation(3)
	
	def on_select(self, widget, data=None): #Accede a Seleccion
		self.__view.change_operation(4)

	def on_to_pdf(self, widget, data=None):
		self.__view.show_window_export()

	def on_print(self, widget, data=None):
		self.__view.show_print()

	def on_export_clicked(self, widget, data=None):
		self.__view.to_pdf()

	def on_destroyloader(self, widget, data=None):
		self.__view.destroy_export()

	def on_clicked(self, widget, data=None):
		self.__view.option_clicked(data)

	def motion_clicked(self, widget, data=None):
		self.__view.option_moved(data)

	def on_click_released(self, widget, data=None):
		self.__view.option_released(data)



a = Controller()
a.throw_app()
		
