try:
	from gi.repository import Gtk, Gdk
except:
	print "DEPENCENCIAS INSATIFECHAS:  >= GTK3 "
	print "CORRIENDO CON GTK 2.X ... PUEDEN HABER PROBLEMAS"
	try:
		import gtk
	except:
		print "GTK NO DISPONIBLE EN TU SISTEMA"
		exit(1)

from multiprocessing import Process
from Tkinter import *
import squishy
import palette

class Ui:

	def __init__(self):

		self.__loader = Gtk.Builder()
		self.__loader.add_from_file("view_model/ventanas.ui")
		self.__mainWindow = self.__loader.get_object("principal")
		self.__darea = self.__loader.get_object("workstation")
		self.__exportWindow = self.__loader.get_object("export")
		self.__statusBar = self.__loader.get_object("statusbar1")
		self.__printWindow = self.__loader.get_object("printdial")
		self.__menuGrafo = self.__loader.get_object("menu-grafo")
		self.__menuArista = self.__loader.get_object("menu-arista")
		self.__menuNodo = self.__loader.get_object("menu-nodo")
		self.__draw = squishy.Squishy(self.__darea)

		
	def connect_signals(self,controller):
		self.__loader.connect_signals(controller)

	def show_elements(self):
		self.__mainWindow.show()
	
	def change_operation(self, opId):
		self.__draw.set_status(opId)
		self.__draw.reset()
			
	def throw_ui(self):
		self.show_elements()
		Gtk.main()

	def show_window_export(self):
		self.__exportWindow.show()

	def show_print(self):
		self.__printWindow.show()

	def to_pdf(self):
		self.__direction = self.__loader.get_object("export").get_filename()
		self.__formatExport = self.__loader.get_object("formato").get_active_text()
		print self.__direction + self.__formatExport
		#print self.__direction
		self.__draw.create_file(self.__direction, self.__formatExport)
		self.destroy_export()
		
	def stop_ui(self):
		Gtk.main_quit()

	def destroy_export(self):
		self.__exportWindow.hide()

	def option_clicked(self, data = None):
		if self.__draw.get_status() == 1:
			if data.button == 1:
				self.__draw.insert_new_node(data)
		if self.__draw.get_status() == 2:
			return True
		if self.__draw.get_status() == 3:
			if data.button == 1:
				self.__draw.insert_edge(data)
		if self.__draw.get_status() == 4:
			if data.button == 1:
				self.__draw.select_area(data)
			if data.button == 3:
				self.__draw.reset()
		if data.button == 3:
			if self.__draw.get_over(data) == 1:
				self.__menuNodo.popup(None, None, None, None, data.button, data.time)
			if self.__draw.get_over(data) == 2:
				self.__menuArista.popup(None, None, None, None, data.button, data.time)
			if self.__draw.get_over(data) == 3: 
				self.__menuGrafo.popup(None, None, None, None, data.button, data.time)

	def option_moved(self, data = None):
		if self.__draw.get_status() == 1:
			return True
		if self.__draw.get_status() == 2:
			self.__draw.move_node(data)
		if self.__draw.get_status() == 3:
			return True
		if self.__draw.get_status() == 4:
			self.__draw.move_selected(data)

	def option_released(self, data = None):
		if self.__draw.get_status() == 1:
			return True
		if self.__draw.get_status() == 2:
			return True
		if self.__draw.get_status() == 3:
			return True
		if self.__draw.get_status() == 4:
			if data.button == 1:
				if self.__draw.get_ind() == 0:
					self.__draw.select_area_end(data)
					print "Fin seleccion"


